import { Component, OnInit } from '@angular/core';
import { IonItemSliding } from '@ionic/angular';
import { Subscription } from 'rxjs';
import { BookingService } from './booking.service';
import { Booking } from './booking.model';

@Component({
  selector: 'app-bookings',
  templateUrl: './bookings.page.html',
  styleUrls: ['./bookings.page.scss'],
})
export class BookingsPage implements OnInit {
  loadedBookings: Booking[];
  private listSubscription : Subscription

  constructor(private bookingService: BookingService) {
        this.listSubscription = new Subscription
   }

  ngOnInit() {
    this.loadedBookings = this.bookingService.bookings;
    this.listSubscription = this.bookingService.listChanged.subscribe(booking => {
        this.loadedBookings = booking
    })
  }

  onCancelBooking(offerId: string, slidingEl: IonItemSliding) {
    this.removeBooking(offerId)
    slidingEl.close();
    
    // cancel booking wiht id offerId
  }

  removeBooking(id:string){
     this.bookingService.removeBooking(id)
    
  }

}
