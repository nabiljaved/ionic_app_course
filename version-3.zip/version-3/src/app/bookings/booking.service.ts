import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { Booking } from './booking.model';

@Injectable({ providedIn: 'root' })
export class BookingService {

  listChanged = new Subject<Booking[]>()

  private _bookings: Booking[] = [
      {
          id: 'xyz',
          placeId: 'p1',
          placeTitle: 'Manhattan Mansion',
          guestNumber: 2,
          userId: 'abc'
      }
  ];

  get bookings() {
    return [...this._bookings];
  }

  removeBooking(id:string){
    
      const index =  this._bookings.findIndex(bid => bid.id == id)
      this._bookings.splice(index, 1)
      this.listChanged.next(this._bookings)
  }

}
